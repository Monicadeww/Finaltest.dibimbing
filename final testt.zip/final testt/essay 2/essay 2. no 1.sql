INSERT INTO dim_user (user_id, user_name, country)
SELECT user_id, user_name, country FROM dim_user;
INSERT INTO dim_post (post_id, post_text, post_date)
SELECT post_id, post_text, post_date FROM dim_post;
INSERT INTO dim_date (date_id, full_date)
SELECT DISTINCT ROW_NUMBER() OVER (ORDER BY post_date) AS date_id, post_date
FROM dim_post
UNION
SELECT DISTINCT ROW_NUMBER() OVER (ORDER BY full_date) AS date_id, full_date
FROM dim_date;
