CREATE TABLE fact_daily_posts (
    user_id INT,
    date_id INT,
    posts_count INT,
    PRIMARY KEY (user_id, date_id),
    FOREIGN KEY (user_id) REFERENCES dim_user(user_id),
    FOREIGN KEY (date_id) REFERENCES dim_date(date_id)
);
