CREATE TABLE fact_post_performance (
    post_id INT,
    user_id INT,
    date_id INT,
    post_views INT,
    likes INT,
    PRIMARY KEY (post_id, user_id, date_id),
    FOREIGN KEY (post_id) REFERENCES dim_post(post_id),
    FOREIGN KEY (user_id) REFERENCES dim_user(user_id),
    FOREIGN KEY (date_id) REFERENCES dim_date(date_id)
);

