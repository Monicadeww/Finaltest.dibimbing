INSERT INTO fact_daily_posts (user_id, date_id, posts_count)
SELECT
    dp.post_id,
    dd.date_id,
    COUNT(dp.post_id) AS posts_count
FROM
    dim_post dp
JOIN
    dim_date dd ON dp.post_date = dd.full_date
GROUP BY
    dp.post_id, dd.date_id;
